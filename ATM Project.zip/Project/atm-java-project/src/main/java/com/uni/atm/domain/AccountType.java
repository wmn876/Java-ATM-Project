package com.uni.atm.domain;

public enum AccountType {
    
    SAVING

    
}
