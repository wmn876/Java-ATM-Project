package com.uni.atm.domain;

public enum CardType {
    
    CREDIT,
    DEBT
    
}
